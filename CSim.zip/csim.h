/*
TO IMPLEMENT THIS LANGUAGE INTO C:
    1. Add this file into your a folder that you are coding in
    2. Type in #include "csim.h"

NOTE:
    - You will still need a main function
    - This language was made to simplify C
    - You will still be able to run C
*/





///////////////////////////////////
// Content //
///////////////////////////////////

/*
DATA TYPES:
    - num (Whole Numbers)
    - dec (Decimals)
    - letter
    - string
    - array of letters
    - bool
*/

/*
ARRAYS:
    - numArray
    - decArray
    - letterArray
    - stringArray
    - boolArray
*/





///////////////////////////////////
// Headers //
///////////////////////////////////

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <windows.h>

///////////////////////////////////
// Data Types //
///////////////////////////////////

typedef int num;
typedef double dec;
typedef char let;
typedef char* str;
typedef char letArr[100];

///////////////////////////////////
// Arrays //
///////////////////////////////////

typedef int numArr[100];
typedef double decAr[100];
typedef char* strArr[100];

///////////////////////////////////
// Output //
///////////////////////////////////

num outNum(num number){
    printf("%d", number);
}
dec outDec(dec decimal){
    printf("%lf", decimal);
}
let outLet(let letter){
    printf("%c", letter);
}
str outStr(str string){
    printf("%s", string);
}
str outLetArr(letArr letters){
    printf("%s", letters);
}

///////////////////////////////////
// Input //
///////////////////////////////////

num inNum(num number){
    scanf(" %d", &number);
    return number;
}
dec inDec(dec decimal){
    scanf(" %lf", &decimal);
    return decimal;
}
let inLet(let letter){
    scanf(" %c", &letter);
    return letter;
}
str inLetArr(str string){
    scanf(" %s", string);
    return string;
}

///////////////////////////////////
// String Library //
///////////////////////////////////

///////////////////////////////////
// Random //
///////////////////////////////////

void randomSeed(){
    srand((unsigned) time(NULL));
}
int random(int max, bool includeZero){
    max += 1;
    num number;

    if(includeZero){
        number = rand() % max;
    }
    else{
        number = rand() % max + 1;

        if(number != 1){
            number -= 1;
        }
    }

    return number;
}
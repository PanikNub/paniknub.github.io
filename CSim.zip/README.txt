TO IMPLEMENT THIS LANGUAGE INTO C:
    1. Move the csim.h file into your coding folder
    2. Type in #include "csim.h" in any C file in that coding folder.

NOTE:
    - You will still need a main function
    - This language was made to simplify C
    - You will still be able to run C
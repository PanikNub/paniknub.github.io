#include <stdio.h>
#include <stdbool.h>
#include <ctype.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <windows.h>
#include "main.h"

int main(){
    srand((unsigned) time(NULL));
    beg();

    int m = 0;
    int p = 25;
    int chan = 10;
    bool ru = true;

    char ac;
    while(ru){
        printf("Action: ");
        scanf(" %c", &ac);
        ac = toupper(ac);

        switch((int) ac){
            case 87: // W
                printf("Cooking: ");
                for(int i = 0; i < 10; i++){
                    printf("-");
                    sl(1000);
                }
                printf(" Done!\nDelivery: ");

                for(int i = 0; i < 10; i++){
                    printf("-");
                    sl(0500);
                }
                printf(" Done!\n\n");

                m += rand() % chan + 1;
                printf("Money: $%d\n", m);
                break;
            case 80: // P
                if(m >= p){
                    m -= p;
                    chan *= 2;
                    p *= 2;

                    printf("Promotion successfuly brought!\n");
                    printf("Money: $%d\n\n", m);
                }
                else{
                    printf("You need $%d more!\n\n", p - m);
                }
                break;

            case 72: // H
                h(p);
                break;
            case 76: // L
                ru = false;
                break;
        }
    }
    sl(1000);
    return 0;
}


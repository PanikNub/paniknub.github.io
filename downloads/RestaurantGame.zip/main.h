#pragma once

void beg(){
    printf("\n-- Restaurant Game --\nType in H for a list of commands!\n\n");
}
void sl(int x){
    Sleep(x);
}

void h(int p){
    printf("- W: Work\n- P: Promotion($%d)\n- L: Leave\n\n", p);
}
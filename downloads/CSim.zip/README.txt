HOW TO USE:
 1. Get a C compiler if you don't have one (Recommend: https://sourceforge.net/projects/mingw/)
 2. Move csim.h into a folder that you will code in
 3. #include "sim.h"

NOTE: I personally recommend learning C before this (Recommend: https://www.w3schools.com/c/index.php).
 - You will still need an "int main(){}" (or you could do num main(){})

---------------------------------------------------------
-- Data Types --
---------------------------------------------------------

 - num (whole number)
 - dec (decimal)
 - str (string)
 - letArr(Array of letters) -> This is for specific character manipulation
 - bool (boolean)

Ex: num Number = 5;

---------------------------------------------------------
-- Pointer Data Types --
---------------------------------------------------------

 - memNum
 - memDec
 - memLet
 - str (already a pointer)

Ex:
 num number = 3;
 memNum pNumber = &number;

 outNum(*pNumber);

---------------------------------------------------------
-- Arrays --
---------------------------------------------------------

 - numArr
 - decArr
 - strArr
 - boolArr

Ex: strArr names = {"Bob", "Alex", "John"};

---------------------------------------------------------
-- Random Functions --
---------------------------------------------------------

 - randomSeed()
 - random(max, bool includeZero)

Ex:
  randomSeed();
 
  num number = random(5, true); -> Gets a random number from 0-5
  outNum(number);

---------------------------------------------------------
-- Letter Functions --
---------------------------------------------------------

 - upper(letter)
 - lower(letter)

Ex:
let letter = 'a';
letter = upper(letter); -> 'A'